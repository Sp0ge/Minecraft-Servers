from __future__ import annotations

import hashlib
import json
import shutil
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Any


CONFIG_FILE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("pack.json")

MODRINTH_API = "https://api.modrinth.com/v2"

DEFAULT_HEADERS = {
    "User-Agent": "Universal-Modrinth-Mrpack-Builder/1.0",
    "Accept": "application/json",
}


class BuilderError(RuntimeError):
    pass


class MrpackBuilder:
    def __init__(self, config_path: Path):
        self.config_path = config_path.resolve()

        if not self.config_path.exists():
            raise BuilderError(
                f"Config file not found: {self.config_path}"
            )

        self.root = self.config_path.parent

        with self.config_path.open("r", encoding="utf-8") as f:
            self.config = json.load(f)

        self.validate_config()

        self.pack = self.config["pack"]
        self.minecraft = self.config["minecraft"]
        self.modrinth = self.config.get("modrinth", {})
        self.build_config = self.config.get("build", {})
        self.mods_config = self.config["mods"]

        self.minecraft_version = self.minecraft["version"]
        self.loader = self.minecraft.get("loader", "fabric")
        self.loader_version = self.minecraft["loaderVersion"]

        self.output_dir = self.root / self.build_config.get(
            "outputDirectory",
            "dist",
        )

        self.work_dir = self.root / self.build_config.get(
            "workDirectory",
            ".build",
        )

        self.overrides_dir = self.root / self.build_config.get(
            "overridesDirectory",
            "overrides",
        )

        self.index_file = self.work_dir / "modrinth.index.json"

        self.output_file = self.output_dir / self.pack["output"]

        self.request_delay = float(
            self.modrinth.get("requestDelay", 0.08)
        )

        self.max_retries = int(
            self.modrinth.get("maxRetries", 5)
        )

        self.prefer_release = bool(
            self.modrinth.get("preferRelease", True)
        )

        self.allow_beta = bool(
            self.modrinth.get("allowBeta", True)
        )

        self.allow_alpha = bool(
            self.modrinth.get("allowAlpha", False)
        )

        self.resolve_dependencies = bool(
            self.modrinth.get(
                "resolveRequiredDependencies",
                True,
            )
        )

        self.headers = dict(DEFAULT_HEADERS)

        custom_user_agent = self.modrinth.get("userAgent")

        if custom_user_agent:
            self.headers["User-Agent"] = custom_user_agent

        self.root_mods = self.mods_config.get("include", [])

        self.pins = self.mods_config.get("pins", {})

        self.version_rules = self.mods_config.get(
            "versionRules",
            {},
        )

        self.skip_slugs = set(
            self.mods_config.get("skipSlugs", [])
        )

        self.skip_project_ids = set(
            self.mods_config.get("skipProjectIds", [])
        )

        self.optional_dependencies = bool(
            self.mods_config.get(
                "includeOptionalDependencies",
                False,
            )
        )

        self.project_cache: dict[str, dict] = {}
        self.version_cache: dict[str, dict] = {}

    def validate_config(self):
        required = {
            "pack",
            "minecraft",
            "mods",
        }

        missing = required - set(self.config)

        if missing:
            raise BuilderError(
                f"Missing config sections: {sorted(missing)}"
            )

        pack = self.config["pack"]

        for key in [
            "name",
            "version",
            "output",
        ]:
            if key not in pack:
                raise BuilderError(
                    f"pack.{key} is required"
                )

        minecraft = self.config["minecraft"]

        for key in [
            "version",
            "loader",
            "loaderVersion",
        ]:
            if key not in minecraft:
                raise BuilderError(
                    f"minecraft.{key} is required"
                )

        if not isinstance(
            self.config["mods"].get("include", []),
            list,
        ):
            raise BuilderError(
                "mods.include must be an array"
            )

    def request_json(self, url: str):
        last_error = None

        for attempt in range(
            1,
            self.max_retries + 1,
        ):
            try:
                request = urllib.request.Request(
                    url,
                    headers=self.headers,
                )

                with urllib.request.urlopen(
                    request,
                    timeout=30,
                ) as response:
                    return json.load(response)

            except urllib.error.HTTPError as e:
                last_error = e

                if e.code == 429:
                    wait = min(attempt * 2, 15)

                    print(
                        f"[WAIT] Modrinth rate limit, "
                        f"sleeping {wait}s"
                    )

                    time.sleep(wait)
                    continue

                raise BuilderError(
                    f"HTTP {e.code}: {url}"
                ) from e

            except Exception as e:
                last_error = e

                if attempt == self.max_retries:
                    break

                time.sleep(attempt)

        raise BuilderError(
            f"Request failed: {url}: {last_error}"
        )

    def api(self, path: str):
        time.sleep(self.request_delay)

        return self.request_json(
            f"{MODRINTH_API}{path}"
        )

    def project_info(self, project: str):
        if project in self.project_cache:
            return self.project_cache[project]

        encoded = urllib.parse.quote(
            project,
            safe="",
        )

        data = self.api(
            f"/project/{encoded}"
        )

        self.project_cache[project] = data
        self.project_cache[data["id"]] = data
        self.project_cache[data["slug"]] = data

        return data

    def version_info(self, version_id: str):
        if version_id in self.version_cache:
            return self.version_cache[version_id]

        encoded = urllib.parse.quote(
            version_id,
            safe="",
        )

        data = self.api(
            f"/version/{encoded}"
        )

        self.version_cache[version_id] = data

        return data

    def project_versions(self, project_id: str):
        params = urllib.parse.urlencode({
            "game_versions": json.dumps(
                [self.minecraft_version]
            ),
            "loaders": json.dumps(
                [self.loader]
            ),
        })

        encoded = urllib.parse.quote(
            project_id,
            safe="",
        )

        return self.api(
            f"/project/{encoded}/version?{params}"
        )

    def compatible_with_target(
        self,
        version: dict,
    ):
        return (
            self.minecraft_version
            in version.get("game_versions", [])
            and self.loader
            in version.get("loaders", [])
        )

    def get_rule(
        self,
        project: dict,
    ) -> dict[str, Any]:
        project_id = project["id"]
        slug = project["slug"]

        if project_id in self.version_rules:
            return self.version_rules[project_id]

        if slug in self.version_rules:
            return self.version_rules[slug]

        return {}

    def get_pin(
        self,
        project: dict,
    ) -> str | None:
        project_id = project["id"]
        slug = project["slug"]

        if project_id in self.pins:
            return self.pins[project_id]

        if slug in self.pins:
            return self.pins[slug]

        return None

    def version_allowed_by_type(
        self,
        version: dict,
        project: dict | None = None,
    ):
        version_type = version.get(
            "version_type",
            "release",
        )

        if project:
            rule = self.get_rule(project)

            allowed_types = rule.get(
                "versionTypes"
            )

            if allowed_types is not None:
                return version_type in allowed_types

        if version_type == "release":
            return True

        if version_type == "beta":
            return self.allow_beta

        if version_type == "alpha":
            return self.allow_alpha

        return False

    def apply_version_rule(
        self,
        versions: list[dict],
        rule: dict,
    ):
        if not rule:
            return versions

        result = list(versions)

        exact = rule.get("exact")

        if exact:
            result = [
                v
                for v in result
                if v.get("version_number") == exact
            ]

        prefix = rule.get("prefix")

        if prefix:
            result = [
                v
                for v in result
                if v.get(
                    "version_number",
                    "",
                ).startswith(prefix)
            ]

        contains = rule.get("contains")

        if contains:
            result = [
                v
                for v in result
                if contains
                in v.get("version_number", "")
            ]

        excludes = rule.get(
            "excludeContains",
            [],
        )

        if isinstance(excludes, str):
            excludes = [excludes]

        for excluded in excludes:
            result = [
                v
                for v in result
                if excluded
                not in v.get(
                    "version_number",
                    "",
                )
            ]

        allowed_types = rule.get(
            "versionTypes"
        )

        if allowed_types:
            result = [
                v
                for v in result
                if v.get("version_type")
                in allowed_types
            ]

        version_id = rule.get("versionId")

        if version_id:
            result = [
                v
                for v in result
                if v.get("id") == version_id
            ]

        return result

    def select_version(
        self,
        project: dict,
    ):
        pin = self.get_pin(project)

        if pin:
            version = self.version_info(pin)

            if version.get("project_id") != project["id"]:
                raise BuilderError(
                    f"Pinned version {pin} does not "
                    f"belong to {project['slug']}"
                )

            if not self.compatible_with_target(
                version
            ):
                raise BuilderError(
                    f"Pinned version {pin} of "
                    f"{project['slug']} does not "
                    f"support {self.loader} "
                    f"{self.minecraft_version}"
                )

            print(
                f"[PIN] {project['slug']} -> "
                f"{version['version_number']}"
            )

            return version

        versions = self.project_versions(
            project["id"]
        )

        versions = [
            v
            for v in versions
            if self.compatible_with_target(v)
            and self.version_allowed_by_type(v)
        ]

        rule = self.get_rule(project)

        versions = self.apply_version_rule(
            versions,
            rule,
        )

        if not versions:
            raise BuilderError(
                f"No allowed version found for "
                f"{project['title']} "
                f"({project['slug']})"
            )

        if self.prefer_release:
            releases = [
                v
                for v in versions
                if v.get("version_type")
                == "release"
            ]

            if releases:
                return releases[0]

        return versions[0]

    def choose_primary_file(
        self,
        version: dict,
    ):
        files = version.get("files", [])

        if not files:
            raise BuilderError(
                f"Version {version.get('id')} "
                f"contains no files"
            )

        candidates = [
            f
            for f in files
            if f.get(
                "filename",
                "",
            ).lower().endswith(".jar")
            and f.get("file_type")
            not in {
                "sources-jar",
                "dev-jar",
                "javadoc-jar",
            }
        ]

        if not candidates:
            candidates = files

        for file in candidates:
            if file.get("primary"):
                return file

        return candidates[0]

    def should_skip(
        self,
        project: dict,
    ):
        return (
            project.get("slug")
            in self.skip_slugs
            or project.get("id")
            in self.skip_project_ids
        )

    def resolve_dependency_project(
        self,
        dependency: dict,
    ):
        project_id = dependency.get(
            "project_id"
        )

        version_id = dependency.get(
            "version_id"
        )

        if project_id:
            return self.project_info(
                project_id
            )

        if version_id:
            version = self.version_info(
                version_id
            )

            return self.project_info(
                version["project_id"]
            )

        return None

    def resolve_dependency_version(
        self,
        dependency: dict,
        project: dict,
    ):
        exact_version_id = dependency.get(
            "version_id"
        )

        if exact_version_id:
            exact = self.version_info(
                exact_version_id
            )

            if (
                self.compatible_with_target(exact)
                and self.version_allowed_by_type(
                    exact
                )
            ):
                rule = self.get_rule(project)

                if not rule:
                    return exact

                allowed = self.apply_version_rule(
                    [exact],
                    rule,
                )

                if allowed:
                    return exact

            print(
                f"[WARN] Dependency requested "
                f"{project['slug']} "
                f"{exact.get('version_number')} "
                f"but config rules override it"
            )

        return self.select_version(project)

    def resolve_all(self):
        queue = []
        resolved = {}

        for item in self.root_mods:
            if isinstance(item, str):
                identifier = item
                enabled = True
            else:
                identifier = (
                    item.get("project")
                    or item.get("slug")
                    or item.get("id")
                )

                enabled = item.get(
                    "enabled",
                    True,
                )

            if not enabled:
                print(
                    f"[-] Disabled root mod: "
                    f"{identifier}"
                )
                continue

            if not identifier:
                raise BuilderError(
                    f"Invalid mod entry: {item}"
                )

            project = self.project_info(
                identifier
            )

            if self.should_skip(project):
                print(
                    f"[-] Skipped root mod: "
                    f"{project['slug']}"
                )
                continue

            queue.append({
                "project": project,
                "dependency": None,
                "source": "root",
            })

        while queue:
            item = queue.pop(0)

            project = item["project"]
            project_id = project["id"]

            if project_id in resolved:
                continue

            if self.should_skip(project):
                print(
                    f"[-] Skipped: "
                    f"{project['slug']}"
                )
                continue

            dependency = item["dependency"]

            if dependency:
                version = (
                    self.resolve_dependency_version(
                        dependency,
                        project,
                    )
                )
            else:
                version = self.select_version(
                    project
                )

            file = self.choose_primary_file(
                version
            )

            resolved[project_id] = {
                "project": project,
                "version": version,
                "source": item["source"],
            }

            print(
                f"[+] {project['title']}"
                f" | {version['version_number']}"
                f" | {file['filename']}"
                f" | source={item['source']}"
            )

            if not self.resolve_dependencies:
                continue

            for dep in version.get(
                "dependencies",
                [],
            ):
                dep_type = dep.get(
                    "dependency_type"
                )

                allowed_dependency_types = {
                    "required",
                }

                if self.optional_dependencies:
                    allowed_dependency_types.add(
                        "optional"
                    )

                if (
                    dep_type
                    not in allowed_dependency_types
                ):
                    continue

                dep_project = (
                    self.resolve_dependency_project(
                        dep
                    )
                )

                if dep_project is None:
                    print(
                        f"[WARN] Cannot resolve "
                        f"dependency of "
                        f"{project['slug']}: {dep}"
                    )
                    continue

                if self.should_skip(
                    dep_project
                ):
                    print(
                        f"[-] Dependency skipped: "
                        f"{dep_project['slug']} "
                        f"<- {project['slug']}"
                    )
                    continue

                if (
                    dep_project["id"]
                    in resolved
                ):
                    continue

                queue.append({
                    "project": dep_project,
                    "dependency": dep,
                    "source": project["slug"],
                })

        return resolved

    def environment_to_mrpack(
        self,
        environment: str,
    ):
        mapping = {
            "client_and_server": {
                "client": "required",
                "server": "required",
            },
            "client_only": {
                "client": "required",
                "server": "unsupported",
            },
            "client_only_server_optional": {
                "client": "required",
                "server": "optional",
            },
            "singleplayer_only": {
                "client": "required",
                "server": "unsupported",
            },
            "server_only": {
                "client": "unsupported",
                "server": "required",
            },
            "server_only_client_optional": {
                "client": "optional",
                "server": "required",
            },
            "dedicated_server_only": {
                "client": "unsupported",
                "server": "required",
            },
            "client_or_server": {
                "client": "optional",
                "server": "optional",
            },
            "client_or_server_prefers_both": {
                "client": "required",
                "server": "required",
            },
            "unknown": {
                "client": "required",
                "server": "optional",
            },
        }

        return mapping.get(
            environment,
            {
                "client": "required",
                "server": "optional",
            },
        )

    def manifest_entry(
        self,
        project: dict,
        version: dict,
    ):
        file = self.choose_primary_file(
            version
        )

        hashes = file.get(
            "hashes",
            {},
        )

        if not hashes.get("sha1"):
            raise BuilderError(
                f"No SHA1 for "
                f"{file['filename']}"
            )

        if not hashes.get("sha512"):
            raise BuilderError(
                f"No SHA512 for "
                f"{file['filename']}"
            )

        if not file.get("url"):
            raise BuilderError(
                f"No download URL for "
                f"{file['filename']}"
            )

        environment = version.get(
            "environment",
            "client_and_server",
        )

        return {
            "path": (
                f"mods/{file['filename']}"
            ),
            "hashes": {
                "sha1": hashes["sha1"],
                "sha512": hashes["sha512"],
            },
            "env": (
                self.environment_to_mrpack(
                    environment
                )
            ),
            "downloads": [
                file["url"]
            ],
            "fileSize": file["size"],
        }

    def build_index(
        self,
        resolved: dict,
    ):
        files = []
        seen_paths = set()

        items = sorted(
            resolved.values(),
            key=lambda item:
                item["project"]["title"].lower(),
        )

        for item in items:
            entry = self.manifest_entry(
                item["project"],
                item["version"],
            )

            if entry["path"] in seen_paths:
                continue

            seen_paths.add(
                entry["path"]
            )

            files.append(entry)

        dependencies = {
            "minecraft":
                self.minecraft_version,
        }

        if self.loader == "fabric":
            dependencies[
                "fabric-loader"
            ] = self.loader_version

        elif self.loader == "quilt":
            dependencies[
                "quilt-loader"
            ] = self.loader_version

        elif self.loader == "forge":
            dependencies[
                "forge"
            ] = self.loader_version

        elif self.loader == "neoforge":
            dependencies[
                "neoforge"
            ] = self.loader_version

        else:
            raise BuilderError(
                f"Unsupported loader: "
                f"{self.loader}"
            )

        return {
            "formatVersion": 1,
            "game": "minecraft",
            "versionId":
                self.pack["version"],
            "name":
                self.pack["name"],
            "summary":
                self.pack.get(
                    "summary",
                    "",
                ),
            "files":
                files,
            "dependencies":
                dependencies,
        }

    def prepare(self):
        if self.work_dir.exists():
            shutil.rmtree(
                self.work_dir
            )

        self.work_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        self.output_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        if not self.overrides_dir.exists():
            self.overrides_dir.mkdir(
                parents=True,
                exist_ok=True,
            )

        if self.output_file.exists():
            self.output_file.unlink()

    def write_index(
        self,
        index: dict,
    ):
        with self.index_file.open(
            "w",
            encoding="utf-8",
        ) as f:
            json.dump(
                index,
                f,
                ensure_ascii=False,
                indent=2,
            )

            f.write("\n")

    def add_overrides(
        self,
        archive: zipfile.ZipFile,
    ):
        if not self.overrides_dir.exists():
            return

        for path in (
            self.overrides_dir.rglob("*")
        ):
            if not path.is_file():
                continue

            relative = path.relative_to(
                self.overrides_dir
            )

            archive.write(
                path,
                str(
                    Path("overrides")
                    / relative
                ),
            )

    def create_archive(self):
        with zipfile.ZipFile(
            self.output_file,
            "w",
            compression=zipfile.ZIP_DEFLATED,
            compresslevel=9,
        ) as archive:

            archive.write(
                self.index_file,
                "modrinth.index.json",
            )

            self.add_overrides(
                archive
            )

    def verify_archive(self):
        with zipfile.ZipFile(
            self.output_file,
            "r",
        ) as archive:

            names = archive.namelist()

            if (
                "modrinth.index.json"
                not in names
            ):
                raise BuilderError(
                    "modrinth.index.json "
                    "is missing"
                )

            raw = archive.read(
                "modrinth.index.json"
            )

            index = json.loads(
                raw.decode("utf-8")
            )

        paths = set()

        for entry in index["files"]:
            path = entry["path"]

            if path in paths:
                raise BuilderError(
                    f"Duplicate file: {path}"
                )

            paths.add(path)

            if not path.startswith(
                "mods/"
            ):
                raise BuilderError(
                    f"Invalid mod path: {path}"
                )

            if not entry.get(
                "downloads"
            ):
                raise BuilderError(
                    f"No downloads: {path}"
                )

            hashes = entry.get(
                "hashes",
                {},
            )

            if not hashes.get(
                "sha1"
            ):
                raise BuilderError(
                    f"No SHA1: {path}"
                )

            if not hashes.get(
                "sha512"
            ):
                raise BuilderError(
                    f"No SHA512: {path}"
                )

        return index

    def sha256(self):
        digest = hashlib.sha256()

        with self.output_file.open(
            "rb"
        ) as f:
            while True:
                chunk = f.read(
                    1024 * 1024
                )

                if not chunk:
                    break

                digest.update(chunk)

        return digest.hexdigest()

    def print_summary(
        self,
        resolved: dict,
    ):
        print()
        print("=" * 100)
        print("RESOLVED MODS")
        print("=" * 100)

        items = sorted(
            resolved.values(),
            key=lambda item:
                item["project"]["title"].lower(),
        )

        for item in items:
            project = item["project"]
            version = item["version"]

            print(
                f"{project['title']:<35} "
                f"{version['version_number']:<40} "
                f"{item['source']}"
            )

        print("=" * 100)

    def run(self):
        print()
        print("=" * 70)
        print("Universal Modrinth MRPACK Builder")
        print("=" * 70)

        print(
            f"Config:     "
            f"{self.config_path}"
        )

        print(
            f"Pack:       "
            f"{self.pack['name']} "
            f"{self.pack['version']}"
        )

        print(
            f"Minecraft:  "
            f"{self.minecraft_version}"
        )

        print(
            f"Loader:     "
            f"{self.loader} "
            f"{self.loader_version}"
        )

        print(
            f"Output:     "
            f"{self.output_file}"
        )

        print()

        self.prepare()

        resolved = self.resolve_all()

        self.print_summary(
            resolved
        )

        index = self.build_index(
            resolved
        )

        self.write_index(
            index
        )

        self.create_archive()

        verified = self.verify_archive()

        print()
        print("=" * 70)
        print("BUILD COMPLETE")
        print("=" * 70)

        print(
            f"Mods:       "
            f"{len(verified['files'])}"
        )

        print(
            f"Output:     "
            f"{self.output_file}"
        )

        print(
            f"Size:       "
            f"{self.output_file.stat().st_size:,} bytes"
        )

        print(
            f"SHA256:     "
            f"{self.sha256()}"
        )

        print("=" * 70)


def main():
    try:
        builder = MrpackBuilder(
            CONFIG_FILE
        )

        builder.run()

    except KeyboardInterrupt:
        print()
        print("[ABORTED]")
        sys.exit(130)

    except Exception as e:
        print()
        print(
            f"[ERROR] {e}",
            file=sys.stderr,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()