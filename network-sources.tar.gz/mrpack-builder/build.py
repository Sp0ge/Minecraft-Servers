#!/usr/bin/env python3
"""Version-aware CLI for the supplied KivyClub Modrinth builder (Python 3.10+)."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import tempfile
import urllib.parse
import zipfile
from pathlib import Path

from build_mrpack import BuilderError, MrpackBuilder


def safe_path(value):
    if not isinstance(value, str) or not value or "\\" in value:
        raise BuilderError(f"Unsafe archive path: {value!r}")
    if value.startswith("/") or re.match(r"^[A-Za-z]:", value):
        raise BuilderError(f"Unsafe archive path: {value!r}")
    if any(p in {"", ".", ".."} for p in value.split("/")):
        raise BuilderError(f"Unsafe archive path: {value!r}")
    return value


def validate_index(index):
    seen = set()
    if index.get("formatVersion") != 1 or index.get("game") != "minecraft":
        raise BuilderError("Unsupported index format")
    for entry in index["files"]:
        path = safe_path(entry["path"])
        if path in seen:
            raise BuilderError(f"Duplicate file: {path}")
        seen.add(path)
        for algorithm, length in (("sha1", 40), ("sha512", 128)):
            if not re.fullmatch(r"[0-9a-fA-F]{%d}" % length, entry["hashes"].get(algorithm, "")):
                raise BuilderError(f"Invalid {algorithm}: {path}")
        if not entry["downloads"] or any(
            urllib.parse.urlparse(url).scheme != "https" or " " in url
            for url in entry["downloads"]
        ):
            raise BuilderError(f"Invalid download URL: {path}")
        if not isinstance(entry["fileSize"], int) or entry["fileSize"] < 0:
            raise BuilderError(f"Invalid file size: {path}")
        if any(v not in {"required", "optional", "unsupported"} for v in entry["env"].values()):
            raise BuilderError(f"Invalid environment: {path}")


class Builder(MrpackBuilder):
    def project_versions(self, project_id):
        if not hasattr(self, "lists"):
            self.lists = {}
        if project_id not in self.lists:
            self.lists[project_id] = super().project_versions(project_id)
        return self.lists[project_id]

    def resolve_all(self):
        roots = []
        for item in self.root_mods:
            if isinstance(item, dict) and not item.get("enabled", True):
                continue
            name = item if isinstance(item, str) else item.get("project") or item.get("slug") or item.get("id")
            if not name:
                raise BuilderError(f"Invalid mod entry: {item}")
            project = self.project_info(name)
            if not self.should_skip(project):
                roots.append(project)
        required_versions = {}
        for attempt in range(12):
            resolved = {}; requested = {}; queue = [(p, "root") for p in roots]
            while queue:
                project, source = queue.pop(0)
                ident = project["id"]
                if ident in resolved:
                    continue
                exact_id = required_versions.get(ident)
                version = self.resolve_dependency_version({"version_id": exact_id}, project) if exact_id else self.select_version(project)
                resolved[ident] = {"project": project, "version": version, "source": source}
                if not self.resolve_dependencies:
                    continue
                for dep in version.get("dependencies", []):
                    required = dep.get("dependency_type") == "required"
                    if not required and not (self.optional_dependencies and dep.get("dependency_type") == "optional"):
                        continue
                    other = self.resolve_dependency_project(dep)
                    if other is None:
                        if required:
                            raise BuilderError(f"Unresolvable dependency of {project['slug']}: {dep}")
                        continue
                    if self.should_skip(other):
                        if required:
                            raise BuilderError(f"Required dependency {other['slug']} is excluded; remove it from skip lists")
                        continue
                    if required and dep.get("version_id"):
                        previous = requested.get(other["id"])
                        if previous and previous != dep["version_id"]:
                            raise BuilderError(f"Conflicting exact requirements for {other['slug']}: {previous}, {dep['version_id']}")
                        requested[other["id"]] = dep["version_id"]
                    queue.append((other, project["slug"]))
            if requested == required_versions:
                for item in resolved.values():
                    print(f"[+] {item['project']['slug']} {item['version']['version_number']}")
                return resolved
            required_versions = requested
        raise BuilderError("Dependency resolution did not converge; set consistent pins")

    def resolve_dependency_version(self, dependency, project):
        exact_id = dependency.get("version_id")
        if not exact_id:
            return self.select_version(project)
        exact = self.version_info(exact_id)
        if exact["project_id"] != project["id"] or not self.compatible_with_target(exact):
            raise BuilderError(f"Incompatible exact dependency: {project['slug']} {exact_id}")
        pin = self.get_pin(project)
        if pin and pin != exact_id:
            raise BuilderError(f"Pin conflicts with exact dependency: {project['slug']}")
        if not self.version_allowed_by_type(exact, project) or not self.apply_version_rule([exact], self.get_rule(project)):
            raise BuilderError(f"Rules reject exact dependency: {project['slug']} {exact_id}")
        return exact

    def validate_resolution(self, resolved):
        for item in resolved.values():
            for dep in item["version"].get("dependencies", []):
                kind = dep.get("dependency_type")
                if kind not in {"required", "incompatible"}:
                    continue
                project_id = dep.get("project_id")
                version_id = dep.get("version_id")
                if not project_id and version_id:
                    project_id = self.version_info(version_id)["project_id"]
                selected = resolved.get(project_id)
                matches = selected and (not version_id or selected["version"]["id"] == version_id)
                if kind == "required" and not matches:
                    raise BuilderError(f"Missing/conflicting dependency of {item['project']['slug']}: {dep}")
                if kind == "incompatible" and matches:
                    raise BuilderError(f"Incompatible mods: {item['project']['slug']} and {project_id}")


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def archive_pack(builder, index):
    validate_index(index)
    builder.output_dir.mkdir(parents=True, exist_ok=True)
    if builder.output_file.parent.resolve() != builder.output_dir.resolve():
        raise BuilderError("pack.output must be a filename, not a path")
    if builder.output_file.suffix != ".mrpack":
        raise BuilderError("pack.output must end in .mrpack")
    fd, temporary = tempfile.mkstemp(dir=builder.output_dir, suffix=".tmp")
    os.close(fd)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            def put(name, data):
                info = zipfile.ZipInfo(safe_path(name), (1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                archive.writestr(info, data)
            put("modrinth.index.json", encode(index))
            for prefix, folder in (
                ("overrides", builder.overrides_dir),
                ("client-overrides", builder.root / "client-overrides"),
                ("server-overrides", builder.root / "server-overrides"),
            ):
                for path in sorted(folder.rglob("*")) if folder.exists() else []:
                    if path.is_symlink():
                        raise BuilderError(f"Symlinks are not supported: {path}")
                    if path.is_file() and path.name not in {".DS_Store", ".gitkeep"}:
                        put(prefix + "/" + path.relative_to(folder).as_posix(), path.read_bytes())
        os.replace(temporary, builder.output_file)
    finally:
        Path(temporary).unlink(missing_ok=True)
    digest = hashlib.sha256(builder.output_file.read_bytes()).hexdigest()
    builder.output_file.with_suffix(".mrpack.sha256").write_text(
        f"{digest}  {builder.output_file.name}\n", encoding="ascii")
    print(f"Built {builder.output_file} ({len(index['files'])} mods), SHA256 {digest}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=Path(__file__).with_name("pack.json"))
    parser.add_argument("--minecraft", help="Target Minecraft version")
    parser.add_argument("--loader", choices=["fabric", "quilt", "forge", "neoforge"])
    parser.add_argument("--loader-version", help="Exact compatible loader version")
    parser.add_argument("--pack-version")
    parser.add_argument("--output", help="Output filename (.mrpack)")
    parser.add_argument("--reset-constraints", action="store_true", help="Clear old pins, versionRules and skip lists for migration")
    parser.add_argument("--allow-alpha", action="store_true", help="Explicitly allow alpha versions")
    parser.add_argument("--locked", action="store_true", help="Build from existing lock without API access")
    parser.add_argument("--lock", type=Path, help="Lock file (default: per target in locks/)")
    args = parser.parse_args()
    try:
        builder = Builder(args.config)
        target_changed = bool((args.minecraft and args.minecraft != builder.minecraft_version) or (args.loader and args.loader != builder.loader))
        if target_changed and not args.loader_version:
            raise BuilderError("Changing target requires --loader-version; choose a loader compatible with the target")
        if args.minecraft:
            builder.minecraft_version = args.minecraft
        if args.loader:
            builder.loader = args.loader
        if args.loader_version:
            builder.loader_version = args.loader_version
        if args.reset_constraints:
            builder.pins = {}; builder.version_rules = {}; builder.skip_slugs = set(); builder.skip_project_ids = set()
        if args.allow_alpha:
            builder.allow_alpha = True
        if args.pack_version:
            builder.pack["version"] = args.pack_version
        if args.output:
            builder.output_file = builder.output_dir / args.output
        elif target_changed:
            tag = re.sub(r"[^A-Za-z0-9._-]", "_", builder.minecraft_version)
            builder.output_file = builder.output_dir / f"KiwyClub-{tag}-{builder.loader}.mrpack"
        effective = {"config": builder.config, "minecraft": builder.minecraft_version,
                     "loader": builder.loader, "loaderVersion": builder.loader_version,
                     "pins": builder.pins, "rules": builder.version_rules,
                     "skipSlugs": sorted(builder.skip_slugs), "skipProjectIds": sorted(builder.skip_project_ids),
                     "allowAlpha": builder.allow_alpha}
        fingerprint = hashlib.sha256(encode(effective)).hexdigest()
        tag = re.sub(r"[^A-Za-z0-9._-]", "_", builder.minecraft_version)
        lock_path = args.lock or builder.root / "locks" / f"{tag}-{builder.loader}.json"
        if args.locked:
            lock = json.loads(lock_path.read_text(encoding="utf-8"))
            if lock.get("configHash") != fingerprint:
                raise BuilderError("Lock does not match configuration; rebuild without --locked")
            index = lock["index"]
        else:
            resolved = builder.resolve_all()
            builder.validate_resolution(resolved)
            index = builder.build_index(resolved)
            validate_index(index)
            lock_path.parent.mkdir(parents=True, exist_ok=True)
            lock_path.write_bytes(encode({"configHash": fingerprint, "index": index,
                "versions": {i["project"]["slug"]: i["version"]["id"] for i in resolved.values()}}))
        archive_pack(builder, index)
    except (BuilderError, OSError, ValueError, KeyError) as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130
    return 0


if __name__ == "__main__":
    sys.exit(main())
